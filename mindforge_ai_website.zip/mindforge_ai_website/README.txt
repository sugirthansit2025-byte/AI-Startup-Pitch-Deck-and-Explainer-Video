MindForge AI website
=====================

How to open:
1. Extract mindforge_ai_website.zip.
2. Open the folder.
3. Double-click index.html. It opens in your browser.

You can edit the website in a code editor such as VS Code.
The idea generator is a front-end demo; it does not call a real AI service.
The explainer video area is a placeholder/script preview until you add a video.
